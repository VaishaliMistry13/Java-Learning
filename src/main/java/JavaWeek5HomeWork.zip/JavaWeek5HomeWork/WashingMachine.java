package JavaWeek5HomeWork;

public class WashingMachine extends Laundry {   //child class

    @Override
    public void Brand(){
        System.out.println("LG");
    }
}

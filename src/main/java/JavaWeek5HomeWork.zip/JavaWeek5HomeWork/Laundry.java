package JavaWeek5HomeWork;

public class Laundry { //Parent class

    public void Brand(){
        System.out.println("Samsung");
    }
    public void Colour(){
        System.out.println("Silver");
    }
}

package JavaWeek5HomeWork;

public class Appliances {

    public static void main(String[] args){

        WashingMachine a1 = new WashingMachine();
        a1.Brand();

        WashingMachine b1 = new WashingMachine();
        b1.Colour();
    }
}

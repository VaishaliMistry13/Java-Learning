package javaweek4homework;

public class ForLoopTable10 {

    public static void main(String[] args){

        int num = 10;

        System.out.println("Table Of 10");

        for (int k=1; k<=10; ++k){

            System.out.println(num+" * "+ k + " = " + (num *k));

        }
    }
}
